<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CorrespondentBank extends Model
{
    //
}
