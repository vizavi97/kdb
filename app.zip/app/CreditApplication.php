<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CreditApplication extends Model
{
    protected $guarded = [];
}
