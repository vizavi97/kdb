<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IndividualsInternetEmail extends Model
{
    //
}
