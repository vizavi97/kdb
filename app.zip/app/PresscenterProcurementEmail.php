<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PresscenterProcurementEmail extends Model
{
    //
}
