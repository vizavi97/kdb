<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CorporateDeposit extends Model
{
    //
}
